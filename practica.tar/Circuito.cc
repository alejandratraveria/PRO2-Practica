#include "Circuito.hh"
      
    Circuito::Circuito() {
        circuito = map<string,Torneo> ();
        categorias = vector<Categoria>();
        numero_torneos = 0;
        c = 0;
        k = 0;
    }

    Circuito::~Circuito() {}

    pair<string,Torneo> Circuito::consultar_torneo(string nombre) const {
        map<string,Torneo>::const_iterator it = circuito.find(nombre);
        return {it->first,it->second};
    }
        
    Categoria Circuito::consultar_categoria(int id_categoria) const {
        return categorias[id_categoria-1];
    }

    bool Circuito::existe_torneo(string nombre) const {
        return circuito.find(nombre) != circuito.end();
    }

    int Circuito::num_torneos() const {
        return numero_torneos;
    }

    bool Circuito::existe_categoria(int id_categoria) const {
        return id_categoria-1 >= 0 and id_categoria-1 < categorias.size();
    }

    void Circuito::modificar_torneo(string nombre, const Torneo& t) {
        circuito[nombre] = t;
    }

    void Circuito::anadir_torneo(string nombre, const Torneo& t) {
        circuito[nombre] = t;
        ++numero_torneos;
    }

    void Circuito::borrar_torneo(string nombre) {
        circuito.erase(nombre);
        --numero_torneos;
    }

    void Circuito::leer_circuito() {
        int C, K;
        cin >> C >> K;
        c = C, k = K;

        categorias = vector<Categoria>(C);

        for (int i = 0; i < C; ++i) {
            string cat;
            cin >> cat;

            Categoria c(cat);
            categorias[i] = c;
        }

        for (int i = 0; i < C; ++i) {
            categorias[i].leer_puntos_por_nivel(K);
        }

        int num_t;
        cin >> num_t;

        for (int i = 0; i < num_t; ++i) {
            string nt;
            int ct;

            cin >> nt >> ct;

            Torneo t(categorias[ct-1]);
            circuito[nt] = t;
            ++numero_torneos;
        }
    }

    void Circuito::escribir_torneos() const {
        cout << numero_torneos << endl;
        for (map<string, Torneo>::const_iterator it = circuito.begin(); it != circuito.end(); ++it) {
            cout << it->first;
            it->second.escribir();
        }
    }

    void Circuito::escribir_categorias() const {
        cout << c << ' ' << k << endl;
        for (int i = 0; i < categorias.size(); ++i) {
            categorias[i].escribir();
        }
    }

