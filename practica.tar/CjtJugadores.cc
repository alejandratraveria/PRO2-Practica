#include "CjtJugadores.hh"

    CjtJugadores::CjtJugadores() {
        jugadores = map<string, Jugador>();
        numero_jugadores = 0;
        ranking = Ranking();
    }

    CjtJugadores::~CjtJugadores() {}
        
    bool CjtJugadores::existe_jugador(string nombre) const {
        map<string, Jugador>::const_iterator it = jugadores.find(nombre);
        return it != jugadores.end();
    }

    Jugador CjtJugadores::consultar_jugador(string nombre) const {
        map<string, Jugador>::const_iterator it = jugadores.find(nombre);
        return it->second;
    }

    pair<string, Jugador> CjtJugadores::consultar_jugadorR(int pos) const {
        return ranking.consultar_jugador(pos);
    }

    int CjtJugadores::num_jugadores() const {
        return numero_jugadores;
    }

    void CjtJugadores::anadir_jugador(string nombre, const Jugador& j) {
        jugadores[nombre] = j;
        ranking.anadir_jugador(nombre, j);
        ++numero_jugadores;
    }

    void CjtJugadores::borrar_jugador(string nombre) {
        map<string,Jugador>::iterator it = jugadores.find(nombre);

        int rank = it->second.consultar_ranking();
        jugadores.erase(it);
        ranking.borrar_jugador(rank);

        it = jugadores.begin();
        int mod = 0;

        while (it != jugadores.end() and mod < jugadores.size() - rank + 1) {
            if (it->second.consultar_ranking() > rank)  {
                it->second.modificar_ranking(it->second.consultar_ranking()-1);
                ++mod;
            }
            ++it;
        }

        --numero_jugadores;
    }

    void CjtJugadores::actualizar_jugadores_torneo_finalizado(const Torneo& t) {

        for (int i = 0; i < t.num_jugadores(); ++i) {
            pair<string,Jugador> j = t.consultar_jugador(i);
            j.second.incrementar_puntos(j.second.consultar_puntos_ultimo_torneo());
            ranking.modificar_jugador(j.second.consultar_ranking(), j.second);
        }

        if (t.consultar_edicion() > 2) {
            for (int i = 0; i < t.jugadores_ultima_edicion(); ++i) {
                pair <string, pair<Jugador, int>> jl = t.consultar_jugador_ultima_edicion(i);
                map<string, Jugador>::iterator it = jugadores.find(jl.first);
                if (it != jugadores.end()) {
                    ranking.incrementar_puntos_jugador(it->second.consultar_ranking(), -jl.second.second);
                }
            }
        }
        ranking.ordenar_ranking();

        for (int i = 0; i < jugadores.size(); ++i) {
            pair<string,Jugador> j = ranking.consultar_jugador(i+1);
            jugadores[j.first] = j.second;
        }
    }

    void CjtJugadores::actualizar_jugadores_torneo_borrado(const Torneo& t) {

        if (t.consultar_edicion() > 1) {
            for (int i = 0; i < t.jugadores_ultima_edicion(); ++i) {
                pair <string, pair<Jugador, int>> j = t.consultar_jugador_ultima_edicion(i);
                map<string, Jugador>::iterator it = jugadores.find(j.first);

                if (it != jugadores.end()) {
                    ranking.incrementar_puntos_jugador(it->second.consultar_ranking(), -j.second.second);
                }
            }

            ranking.ordenar_ranking();

            for (int i = 0; i < jugadores.size(); ++i) {
                pair <string, Jugador> j = ranking.consultar_jugador(i + 1);
                jugadores[j.first] = j.second;
            }
        }
    }

    void CjtJugadores::leer() {
        int n;
        cin >> n;

        for (int i = 0; i < n; ++i) {
            string nj;
            cin >> nj;

            Jugador j(numero_jugadores+1);
            jugadores[nj] = j;

            ++numero_jugadores;
            ranking.anadir_jugador(nj, j);
        }
    }

    void CjtJugadores::escribir() const{
        cout << numero_jugadores << endl;
        for (map<string, Jugador>::const_iterator it = jugadores.begin(); it != jugadores.end(); ++it) {
            cout << it->first;
            it->second.escribir();
        }
    }

    void CjtJugadores::escribirR() const {
        ranking.escribir();
    }