/** @file Categoria.hh
    @brief Especificación de la clase Categoria 
*/
#ifndef _CATEGORIA
#define _CATEGORIA

#ifndef NO_DIAGRAM
#include <iostream>
#include <vector>
#endif

using namespace std;

/** @class Categoria
    @brief Representa una Categoria
*/

class Categoria {
    public:
        //Constructoras

        /** @brief Creadora sin argumento
             \pre <em>Cierto</em>
             \post El resultado es una Categoria vacia
        */ 
        Categoria();

        /** @brief Creadora con parameto
             \pre <em>Cierto</em>
             \post El resultado es una Categoria con nombre <em>nombre</em>
        */ 
        Categoria (string nombre);

        //Destructora:

        /** @brief Destructora
             \pre <em>Cierto</em>
             \post Se destruye el objeto Categoria
        */ 
        ~Categoria();

        //Consultoras:

        /** @brief Consultora del nombre de la categoria
             \pre <em>Cierto</em>
             \post El resultado es el nombre de la categoria
        */ 
        string consultar_nombre() const;

        /** @brief Consultora de los puntos de la categoria en función del nivel <em>lvl</em>
             \pre <em>Cierto</em>
             \post El resultado son los puntos en el nivel <em>lvl</em>
        */ 
        int consultar_puntos_lvl(int lvl) const;

        //Lectura y Escritura:
    
        /** @brief Operación de lectura de los puntos por nivel de una categoria
             \pre <em>Cierto</em>
             \post Se leen del canal estandard los <em>k</em> diferentes puntos por nivel
        */ 
        void leer_puntos_por_nivel(int k);

        /** @brief Operación de escritura de la categoria
             \pre <em>Cierto</em>
             \post Se imprime por el canal estandard el nombre de la categoria y los puntos por nivel
        */ 
        void escribir() const;

    private:

        /** @brief Atributo que almacena el nombre de la categoria
        */ 
        string nombre;
        /** @brief Vector que guarda los puntos por nivel 
        */ 
        vector<int> puntos_nivel;
};


#endif
