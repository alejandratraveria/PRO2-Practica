#include "Jugador.hh"

    Jugador::Jugador() {
        puntos = 0;
        puntos_ultimo_torneo = 0;
        partidos_ganados = 0;
        partidos_perdidos = 0;
        sets_ganados = 0;
        sets_perdidos = 0;
        juegos_ganados = 0;
        juegos_perdidos = 0;
        torneos_d = 0;
    }

    Jugador::Jugador(int ranking) {
        this->ranking = ranking;
        puntos = 0;
        partidos_ganados = 0;
        puntos_ultimo_torneo = 0;
        partidos_perdidos = 0;
        sets_ganados = 0;
        sets_perdidos = 0;
        juegos_ganados = 0;
        juegos_perdidos = 0;
        torneos_d = 0;
    }

    Jugador:: ~Jugador() {}

    int Jugador::consultar_puntos() const {
        return this->puntos;
    }

    int Jugador::consultar_ranking() const {
        return this->ranking;
    }

    int Jugador::consultar_partidos_ganados() const {
        return this->partidos_ganados;
    }

    int Jugador::consultar_partidos_perdidos() const {
        return this->partidos_perdidos;
    }

    int Jugador::consultar_sets_ganados() const {
        return this->sets_ganados;
    }

    int Jugador::consultar_sets_perdidos() const {
        return this->sets_perdidos;
    }

    int Jugador::consultar_juegos_ganados() const {
        return this->sets_ganados;
    }

    int Jugador::consultar_juegos_perdidos() const {
        return this->juegos_perdidos;
    }

    int Jugador::consultar_puntos_ultimo_torneo() const {
        return puntos_ultimo_torneo;
    }

    int Jugador::consultar_torneos() const{
        return torneos_d;
    }

    void Jugador::modificar_ranking(int ranking) {
        this->ranking = ranking;
    }

    void Jugador::incrementar_torneos_disputados(int n) {
        this->torneos_d += n;
    }

    void Jugador::incrementar_puntos(int puntos) {
        this->puntos += puntos;
    }

    void Jugador::incrementar_partidos_ganados(int partidos_ganados) {
        this->partidos_ganados += partidos_ganados;
    }

    void Jugador::incrementar_partidos_perdidos(int partidos_perdidos) {
        this->partidos_perdidos += partidos_perdidos;
    }

    void Jugador::incrementar_sets_ganados(int sets_ganados) {
        this->sets_ganados += sets_ganados;
    }

    void Jugador::incrementar_sets_perdidos(int sets_perdidos) {
        this->sets_perdidos += sets_perdidos;
    }

    void Jugador::incrementar_juegos_ganados(int juegos_ganados) {
        this->juegos_ganados += juegos_ganados;
    }

    void Jugador::incrementar_juegos_perdidos(int juegos_perdidos) {
        this->juegos_perdidos += juegos_perdidos;
    }

    void Jugador::modificar_puntos_ultimo_torneo(int puntos) {
        this->puntos_ultimo_torneo = puntos;
    }

    void Jugador::escribir() const {
        cout << " Rk:" << ranking << " Ps:" << puntos << " Ts:" << torneos_d << " WM:" << partidos_ganados
                << " LM:" << partidos_perdidos << " WS:" << sets_ganados << " LS:" << sets_perdidos <<
                " WG:" << juegos_ganados << " LG:" << juegos_perdidos << endl;
    }
