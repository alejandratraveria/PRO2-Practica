#include "Ranking.hh"

    Ranking::Ranking() {
        ranking = vector<pair<string, Jugador>> ();
    }

    Ranking::~Ranking() {}

    pair<string,Jugador> Ranking::consultar_jugador(int pos) const {
        return ranking[pos-1];
    }

    void Ranking::anadir_jugador(string nombre, const Jugador& j) {
        ranking.push_back({nombre, j});
        ++numero_jugadores;
    }

    void Ranking::borrar_jugador(int pos) {
        for (int i = pos-1; i < ranking.size()-1; ++i) {
            ranking[i] = ranking[i+1];
            ranking[i].second.modificar_ranking(i+1);
        }
        ranking.pop_back();
        --numero_jugadores;
    }

    bool cmp (const pair<string,Jugador>& j1, const pair<string,Jugador>& j2) {
        if (j1.second.consultar_puntos() == j2.second.consultar_puntos()) return j1.second.consultar_ranking() < j2.second.consultar_ranking();
        return j1.second.consultar_puntos() > j2.second.consultar_puntos();
    }
    
    void Ranking::ordenar_ranking() {
        sort(ranking.begin(), ranking.end(), cmp);

        for (int i = 0; i < ranking.size(); ++i) {
            ranking[i].second.modificar_ranking(i+1);
        }
    }

    void Ranking::modificar_jugador(int pos, Jugador j) {
        ranking[pos-1].second = j;
    }

    void Ranking::incrementar_puntos_jugador(int pos, int j) {
        ranking[pos-1].second.incrementar_puntos(j);
    }

    void Ranking::escribir() const {
        for (int i = 0; i < ranking.size(); ++i) {
            cout << ranking[i].second.consultar_ranking() << " " << ranking[i].first << " " << ranking[i].second.consultar_puntos() << endl;
        }
    }