/** @file Ranking.hh
    @brief Especificación de la clase Ranking
*/
#ifndef _RANKING
#define _RANKING

#include "Jugador.hh"

#ifndef NO_DIAGRAM
#include <algorithm>
#include <vector>
#endif

using namespace std;

/** @class Ranking
    @brief Representa un Ranking 
*/

class Ranking {
    public:
      //Constructoras:

        /** @brief Creadora sin argumentos
            \pre <em>Cierto</em>
            \post El resultado es un ranking vacio
        */
        Ranking();

        //Destructora:

        /** @brief Creadora sin argumentos
             \pre <em>Cierto</em>
             \post Se destruye el objeto ranking
        */
        ~Ranking();
        
        //Consulturas:

        /** @brief Consultora que consulta un jugador en el ranking segun su posición <em>pos</em>
             \pre  <em>pos</em> > 0 y <em>pos</em> <= num_jugadores
             \post El resultado es el nombre y el jugador con posición <em>pos</em>
        */
        pair<string,Jugador> consultar_jugador(int pos) const;

        //Modificadoras:

        /** @brief Modificadora que modifica un ranking añadiendo un jugador <em>j</em> con nombre <em>nombre</em>
             \pre El jugador <em>j</em> con nombre <em>nombre</em> no pertenece al ranking
             \post El resultado es el ranking con el nuevo jugador <em>j</em> con nombre <em>nombre</em>
        */
        void anadir_jugador(string nombre, const Jugador& j);

        /** @brief Modificadora que modifica el ranking eliminando un jugador con nombre <em>nombre</em>
             \pre El jugador con nombre <em>nombre</em> pertenece al ranking y <em>pos</em> > 0 y <em>pos</em> <= num_jugadores
             \post El resultado es el ranking sin el jugador con nombre <em>nombre</em>
        */
        void borrar_jugador(int pos);

        /** @brief Modificadora que ordena el ranking
             \pre <em>Cierto</em>
             \post El resultado es el ranking ordenado por puntos de manera decreciente y en caso de empate con el ranking de manera creciente, también actualiza el ranking de los jugadores que lo necesiten
        */ 
        void ordenar_ranking();

        /** @brief Modificadora que actualiza el jugador <em>j</em> con la posición <em>pos</em>
             \pre El jugador <em>j</em> existe y <em>pos</em> > 0 y <em>pos</em> <= num_jugadores
             \post El jugador en la posición <em>pos</em> pasa a ser <em>j</em>
        */ 
        void modificar_jugador(int pos, Jugador j);

        /** @brief Modificadora que incrementa los puntos del jugador <em>j</em> con posición <em>pos</em>
             \pre El jugador <em>j</em> existe
             \post El resultado es el jugador <em>j</em> con ranking <em>pos</em> con sus puntos incrementados 
        */ 
        void incrementar_puntos_jugador(int pos, int j);

        //Escritura:

        /** @brief Operación de escritura del ranking 
             \pre <em>Cierto</em>
             \post Se escribe en el canal estandard todos los jugadores pertenecientes al ranking ordenados en orden creciente segun su posición en el ranking
        */
        void escribir() const;


    private:
      /** @brief Vector de nombres de los jugadores y los jugadores en si ordenado decrecientemente por puntos donde i + 1 es el ranking de cada jugador
      */ 
      vector<pair<string, Jugador>> ranking; 
      /** @brief Numero de jugadores en el ranking
      */ 
      int numero_jugadores;
};

#endif