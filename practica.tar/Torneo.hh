/** @file Torneo.hh
    @brief Especificación de la clase Torneo 
*/
#ifndef _TORNEO
#define _TORNEO

#include "Jugador.hh"
#include "Categoria.hh"

#ifndef NO_DIAGRAM
#include <vector>
#include <map>
#include <cmath>
#include "BinTree.hh"
#endif

using namespace std;

/** @class Torneo
    @brief Representa un Torneo 
*/

class Torneo {
    public:
        //Constructoras:

        /** @brief Creadora sin argumentos
             \pre <em>Cierto</em>
             \post El resultado es un torneo vacio
        */
        Torneo();

        /** @brief Creadora con parametros
             \pre <em>Cierto</em>
             \post El resultado es un torneo con nombre <em>nombre</em> y edición <em>edición</em>
        */
        Torneo(const Categoria& c);

        //Destructora:

        /** @brief Destructora
             \pre <em>Cierto</em>
             \post Se destruye el objeto torneo
        */
        ~Torneo();
        
        //Consultoras:

        /** @brief Consultora de la edición de un torneo
             \pre <em>Cierto</em>
             \post El resultado es el numero de edición del torneo
        */
        int consultar_edicion() const;

        /** @brief Consultora del jugador con posición <em>rank_rel</em> 
             \pre El jugador con posición <em>rank_el</em> existe
             \post El resultado es el nombre y el jugador en la posición <em>rank_rel</em>
        */  
        pair<string,Jugador> consultar_jugador(int rank_rel) const;

        /** @brief Consultora del jugador con posición <em>pos</em>
             \pre El jugador con posición <em>pos</em> existe
             \post El resultado es el nombre, el jugador con posición <em>pos</em> con los puntos de la última edición
        */  
        pair<string,pair<Jugador,int>> consultar_jugador_ultima_edicion(int pos) const;

        /** @brief Consultora que consulta el numero de jugadores de la última edición
             \pre <em>Cierto</em>
             \post El resultado es el numero de jugadores que participaron el la última edición
        */  
        int jugadores_ultima_edicion() const;

        /** @brief Consulta el numero de jugadores del torneo
             \pre <em>Cierto</em>
             \post El resultado es el numero de jugadores que participan en el torneo 
        */  
        int num_jugadores() const;

        /** @brief Consultora de la categoria de un torneo
             \pre <em>Cierto</em>
             \post El resultado es el nombre de la categoria del torneo y su nivel
        */
        Categoria consultar_categoria() const;

        //Modificadoras:

        /** @brief Modificadora que resetea los valores de un torneo menos los jugadores de la última edición
             \pre <em>Cierto</em>
             \post El resultado es un torneo vacio con la lista de jugadores de la edición pasada
        */  
        void vaciar_torneo();

        /** @brief Modificadora que actualiza los jugadores de la edición pasada
             \pre El torneo tiene que haber finalizado
             \post El resultado es el mismo torneo con el conjunto de jugadores de la edición pasada actualizado
        */  
        void actualizar_ultimo_torneo();
        
        /** @brief Modificadora inicializadora de un torneo
             \pre Todos los jugadores inscritos existen
             \post El resultado es el cuadro de emparejamientos del torneo y el torneo se considera inicializado
        */
        void iniciar_torneo();

        /** @brief Modificadora finalizadora de un torneo
             \pre Se ha generado el cuadro de emparejamientos
             \post Se imprime por el canal estandard el cuadro de resultados del torneo
        */
        void finalizar_torneo();

        /** @brief Modificadora que modifica el torneo añadiendo un jugador <em>j</em>
             \pre El jugador <em>j</em> no existe dentro del torneo
             \post El resultado es el torneo mas el jugador <em>j</em>
        */
        void anadir_jugador(string nombre, const Jugador& j);

        /** @brief Modificadora que asigna al jugador <em>j</em> una nueva posicion <em>pos</em> en el ranking
             \pre El jugador <em>j</em> existe
             \post  El resultado es el jugador <em>j</em> con su nueva posicion <em>pos</em>
        */  
        void modificar_jugador(int pos, const Jugador& j);

        /** @brief Modificadora que elimina un jugador con nombre <em>nombre</em> del torneo
             \pre <em>Cierto</em>
             \post Se elimina del conjunto de participantes al jugador con nombre <em>nombre</em>
        */  
        void eliminar_jugador(string nombre);

        //Escritura:

        /** @brief Operación de escritura de la categoria de un torneo
             \pre <em>Cierto</em>
             \post Se imprime por el canal estandard el nombre de la categoria del torneo
        */  
        void escribir() const;

    private:
        /** @brief Edición del torneo
        */ 
        int edicion;
        /** @brief Numero de participantes
        */ 
        int numero_inscritos;
        /** @brief Vector que guarda el nombre de los jugadores y los jugadores
        */ 
        vector<pair<string, Jugador>> jugadores;
        /** @brief Categoria del torneo
        */ 
        Categoria categoria;
        /** @brief Arbol cuadro de emparejamientos
        */ 
        BinTree<int>cuadro_emparejamientos;
        /** @brief Arbol de resultados
        */ 
        BinTree<string> resultados;
        /** @brief Vector que almacena el nombre de los jugadores de ediciones pasadas, los jugadores en si y los puntos ganados en dicha edicion
        */ 
        vector<pair<string, pair<Jugador,int>>> last_players_points;

        /** @brief Genera el cuadro de emparejamientos
             \pre <em>Cierto</em>
             \post El resultado es el cuadro de emparejamientos con sus ciertas restricciones 
        */  
        void get_cuadro(const int N, const int M, const int H, int M_Z, int a_prev, int lvl, BinTree<int>& b);

        /** @brief Operación de lectura de los resultados
             \pre <em>Cierto</em>
             \post Se lee del canal estandard los resultados   
        */  
        void get_results(BinTree<string>& t, int n_nodes, int &i);

        /** @brief Se juega el torneo
             \pre Se tiene que haber generado el cuadro de emparejamientos y haber leido los resultados
             \post Se genera el cuadro de resultados con los diferentes emparejamientos
        */  
        void play_tournament(BinTree<int> v, BinTree<string> t, int lvl, BinTree<int>& res, int M, int N, int H);

        /** @brief Operación de escritura del cuadro de emparejamientos
             \pre <em>Cierto</em>
             \post Se escribe por el canal estandard el cuadro de emparejamientos en preorden
        */  
        void escribir_cuadro(const BinTree<int>& v) const;

        /** @brief Operación de escritura del cuadro de resultados
             \pre <em>Cierto</em>
             \post Se escribe por el canal estandard el cuadro de resultados en preorden
        */  
        void escribir_resultados(const BinTree<int>& v, const BinTree<string>& t) const;
};

#endif