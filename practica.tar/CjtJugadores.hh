/** @file CjtJugadores.hh
    @brief Especificación de la clase CjtJugadores 
*/
#ifndef _CJTJUGADORES
#define _CJTJUGADORES

#include "Ranking.hh"
#include "Torneo.hh"

#ifndef NO_DIAGRAM
#include <map>
#endif

using namespace std;

/** @class CjtJugadores
    @brief Representa un conjunto de jugadores: CjtJugadores
*/

class CjtJugadores {
    public:
        //Constructoras:

        /** @brief Creadora sin argumentos
             \pre <em>Cierto</em>
             \post El resultado es un conjunto de jugadores vacio
        */ 
        CjtJugadores();

        //Destructora:

        /** @brief Destructora
             \pre <em>Cierto</em>
             \post Se destruye el objeto CjtJugadores
        */ 
        ~CjtJugadores();
        
        //Consultoras:
        
        /** @brief Consultora de la existencia de un jugador con nombre <em>nombre</em> en el conjunto
             \pre <em>Cierto</em>
             \post El resultado es true si el jugador con nombre <em>nombre</em> existe y false en caso contrario
        */ 
        bool existe_jugador(string nombre) const;

        /** @brief Consultora del jugador con nombre <em>nombre</em>
             \pre El jugador con nombre <em>nombre</em> existe
             \post El resultado es el jugador con nombre <em>nombre</em>
        */ 
        Jugador consultar_jugador(string nombre) const;

        /** @brief Consulta un jugador con ranking <em>pos</em>
             \pre pos > 0 y pos <= numero_jugadores, el jugador existe
             \post El resultado es el jugador con ranking <em>pos</em>
        */ 
        pair<string, Jugador> consultar_jugadorR(int pos) const;

        /** @brief Consultora del numero actual de jugadores dentro den conjunto de jugadores
             \pre <em>Cierto</em> 
             \post El resultado es el numero actual de jugadores en el conjunto
        */ 
        int num_jugadores() const;

        //Modificadoras:

        /** @brief Modificadora que modifica el conjunto añadiendo el jugador <em>j</em>
             \pre El jugador <em>j</em> no existe en el conjunto 
             \post El resultado es el conjunto de jugadores mas el nuevo jugador <em>j</em>
        */ 
        void anadir_jugador(string nombre, const Jugador& j);

        /** @brief Modificadora que modifica el conjunto eliminando el jugador con nombre <em>nombre</em>
             \pre El jugador con nombre <em>nombre</em> existe en el conjunto 
             \post El resultado es el conjunto de jugadores sin el jugador con nombre <em>nombre</em>
        */ 
        void borrar_jugador(string nombre);

        /** @brief Modificadora que actualiza las estadisticas del conjunto de jugadores al finalizar un torneo
             \pre El torneo <em>t</em> ha finalizado
             \post El resultado es el conjunto de jugadores actualizado, se le suman y restan los puntos a los diferentes jugadores y posteriormente se actualiza el ranking
        */ 
        void actualizar_jugadores_torneo_finalizado(const Torneo& t);

        /** @brief Modificadora que actualiza el conjunto de jugadores al borrar un torneo <em>t</em>
             \pre El torneo <em>t</em> existe
             \post Se actualizan los puntos de los jugadores de la ultima edicion jugada del torneo <em>t</em> en caso de haberla y posteriormente se actualiza el ranking
        */ 
        void actualizar_jugadores_torneo_borrado(const Torneo& t);

        //Lectura y Escritura:

        /** @brief Operación de lectura del conjunto de jugadores
             \pre <em>Cierto</em> 
             \post Se leen del canal estandard los diferentes jugadores que pertenecen al conjunto 
        */ 
        void leer();

        /** @brief Operación de escritura del conjunto de jugadores
             \pre <em>Cierto</em>
             \post Se escriben por el canal estandard los diferentes jugadores del conjunto
        */ 
        void escribir() const;

        /** @brief Operación de escritura del ranking
             \pre <em>Cierto</em>
             \post Se escribe por el canal estandard el ranking
        */ 
        void escribirR() const;

    private:
        /** @brief Map que almacena el nombre de los jugadores y los jugadores en si
        */ 
        map<string, Jugador> jugadores;
        /** @brief Ranking del conjunto de jugadores
        */ 
        Ranking ranking;
        /** @brief Numero de jugadores en el conjunto
        */ 
        int numero_jugadores;
};

#endif