/** @file Circuito.hh
    @brief Especificación de la clase Circuito 
*/

#ifndef _CIRCUITO
#define _CIRCUITO

#include "Torneo.hh"

#ifndef NO_DIAGRAM
#include <map>
#endif

using namespace std;

/** @class Circuito
    @brief Representa un conjunto de torneos 
*/

class Circuito {
    public:
        //Constructoras:

        /** @brief Creadora sin argumentos
             \pre <em>Cierto</em>
             \post El resultado es un circuito vacio
        */ 
        Circuito();

        //Destructora:
        
        /** @brief Destructora
             \pre <em>Cierto</em>
             \post Se destruye el objeto Circuito
        */ 
        ~Circuito();
        
        //Consulturas:

        /** @brief Consultora del torneo con nombre <em>nombre</em>
             \pre El torneo con nombre <em>nombre</em> existe
             \post El resultado es el torneo con nombre <em>nombre</em>
        */ 
        pair<string,Torneo> consultar_torneo(string nombre) const;
        
        
        /** @brief Consultora de la categoria con identificador <em>id_categoria</em>
             \pre La categoria con identificador <em>id_categoria</em> existe
             \post El resultado es el identificador de la categoria con identificador <em>id_categoria</em>
        */
        Categoria consultar_categoria(int id_categoria) const;

        /** @brief Consultora de la existencia del torneo con nombre <em>nombre</em>
             \pre <em>Cierto</em> 
             \post El resultado es true si el torneo con nombre <em>nombre</em> existe y false en caso contrario
        */ 
        bool existe_torneo(string nombre) const;

        /** @brief Consultora del numero de torneos del circuito
             \pre <em>Cierto</em> 
             \post El resultado es el numero actual de torneos en el circuito
        */ 
        int num_torneos() const;

        /** @brief Consultora de la existencia de la categoria con identificador <em>id_categoria</em>
            \pre <em>Cierto</em>
            \post El resultado es true si la categoria con identificador <em>id_categoria</em> existe y false en caso contrario
        */
        bool existe_categoria(int id_categoria) const;

        //Modificadoras:

        /** @brief Modificadora que modifica un torneo <em>t</em> con nombre <em>nombre</em>
             \pre El torneo <em>t</em> con nombre <em>nombre</em> existe en el circuito 
             \post El resultado es el circuito con el torneo <em>t</em> con nombre <em>nombre</em> modificado
        */ 
        void modificar_torneo(string nombre, const Torneo& t);

        /** @brief Modificadora que modifica el circuito añadiendo el torneo <em>t</em> con nombre <em>nombre</em>
             \pre El torneo <em>t</em> con nombre <em>nombre</em> no existe en el circuito 
             \post El resultado es el circuito con el nuevo torneo <em>t</em> con nombre <em>nombre</em>
        */ 
        void anadir_torneo(string nombre, const Torneo& t);

        /** @brief Modificadora que modifica el circuito eliminando el torneo con nombre <em>nombre</em>
             \pre El torneo con nombre <em>nombre</em> existe en el circuito 
             \post El resultado es el circuito sin el torneo con nombre <em>nombre</em>
        */ 
        void borrar_torneo(string nombre);

        //Lectura y Escritura:

        /** @brief Operación de lectura del circuito
             \pre <em>Cierto</em> 
             \post Se leen del canal estandard los diferentes torneos y categorias del circuito
        */ 
        void leer_circuito();

        /** @brief Operación de escritura de los torneos del circuito
             \pre <em>Cierto</em>
             \post Se escriben por el canal estandard los diferentes torneos del circuito
        */ 
        void escribir_torneos() const;

        /** @brief Operación de escritura de las categorias del circuito
             \pre <em>Cierto</em>
             \post Se escriben por el canal estandard las diferentes categorias del circuito
        */ 
        void escribir_categorias() const;

    private:
        /** @brief Guarda el numero de categorias
        */ 
        int c;
        /** @brief Guarda el numero de niveles
        */ 
        int k;
        /** @brief Map que almacena el nombre de los torneos y los torneos en si
        */ 
        map<string,Torneo> circuito;
        /** @brief Vector de categorias del circuito
        */ 
        vector<Categoria> categorias;
        /** @brief Numero de torneos en el circuito
        */ 
        int numero_torneos;
};

#endif
