#include "Circuito.hh"
#include "CjtJugadores.hh"

using namespace std;

/**
 * @mainpage Diseño modular: Gestión de un circuito de torneos de tenis
 
 En esta práctica se construye un programa modular que ofrece un menú de comandos para gestionar un circuito de torneos de tenis. 
 
 Se introducen las clases <em>Circuito</em>, <em>Torneo</em>, <em>Ranking</em>, <em>CjtJugadores</em>, <em>Jugador</em>.

 Se hace una documentación completa tanto de los métodos públicos como de los privados de la especificación e implementación. 

\b Datos \b de \b la \b práctica:
 - Título: Gestión de un circuito de torneos de tenis
 - Autora: Alejandra Traveria Marti
 - Fecha: 17-05-2022
 - Versión: 0.1
 - Lenguaje: C++
 */

/** @file program.cc
    @brief \b Programa \b principal. Se supone que los datos leidos son siempre ciertos, ya que no se incluyen comprovaciones al respecto.  
    Una vez ejecutado el programa se tiene que proporcionar por el canal estandard el conjunto de torneos, categorias y jugadores.
    En el programa principal se incluyen un conjunto de comandos que se describen brevemente a continuación:
        - Nuevo jugador: Se añade un nuevo jugador especificado al conjunto de jugadores y al ranking. En caso de que el jugador ya exista se imprime un error.
        - Nuevo torneo: Se añade un nuevo torneo especificado al circuito. En caso de que el torneo ya exista se imrpime un error.
        - Baja jugador: Se elimina un jugador especificado del conjunto de jugadores y del ranking. En caso de que el jugador no exista se imprime un error.
        - Baja torneo: Se elimina un torneo especificado del circuito. En caso de que el torneo no exista se imrpime un error.
        - Iniciar torneo: Se listan los jugadores inscritos y se genera el cuadro de emparejamientos.
        - Finalizar torneo: Se realiza el torneo y se imprime el cuadro de resultados.
        - Listar ranking: Se listan todos los jugadores en orden creciente segun su posición del ranking.
        - Listar jugadores: Se listan todos los jugadores en orden creciente alfabeticamente.
        - Consultar jugador: Se consultan las estadisticas del jugador especificado.
        - Listar torneos: Se listan los torneos del circuito en orden creciente alfabéticamente.
        - Listar categorias: Se listan las categorias del circuito en orden creciente alfabéticamente.
*/
/**
    @brief Programa principal
*/

int main() {
    Circuito c;
    c.leer_circuito();
    CjtJugadores cjt_j;
    cjt_j.leer();

    string comando;
    cin >> comando;
    while (comando != "fin") {
        if (comando == "nuevo_jugador" or comando == "nj") {
            string nombre;
            cin >> nombre;

            if (comando == "nuevo_jugador") cout << "#nuevo_jugador " << nombre << endl;
            else cout << "#nj " << nombre << endl;

            bool exists = cjt_j.existe_jugador(nombre);
            if (exists) cout << "error: ya existe un jugador con ese nombre" << endl;
            else {
                int ultimo_rank = cjt_j.num_jugadores() + 1;
                Jugador j(ultimo_rank);
                cjt_j.anadir_jugador(nombre, j);
                cout << cjt_j.num_jugadores() << endl;
            }
        }
        else if (comando == "nuevo_torneo" or comando == "nt") {
            string nombre;
            int categoria;
            cin >> nombre >> categoria;

            if (comando == "nuevo_torneo") cout << "#nuevo_torneo " << nombre << " " << categoria << endl;
            else cout << "#nt " << nombre << " " << categoria << endl;

            bool exists_cat = c.existe_categoria(categoria);
            bool exists_t = c.existe_torneo(nombre);

            if (not exists_cat) cout << "error: la categoria no existe" << endl;
            else if (exists_t) cout << "error: ya existe un torneo con ese nombre" << endl;
            else {
                Categoria cat = c.consultar_categoria(categoria);
                Torneo t(cat);
                c.anadir_torneo(nombre, t);
                cout << c.num_torneos() << endl;
            }
        }
        else if (comando == "baja_jugador" or comando == "bj") {
            string nombre;
            cin >> nombre;

            if (comando == "baja_jugador") cout << "#baja_jugador " << nombre << endl;
            else cout << "#bj " << nombre << endl;

            bool exists = cjt_j.existe_jugador(nombre);

            if (not exists) cout << "error: el jugador no existe" << endl;
            else {
                Jugador j = cjt_j.consultar_jugador(nombre);
                cjt_j.borrar_jugador(nombre);
                cout << cjt_j.num_jugadores() << endl;
            }
        }
        else if (comando == "baja_torneo" or comando == "bt") {
            string nombre;
            cin >> nombre;

            if (comando == "baja_torneo") cout << "#baja_torneo " << nombre << endl;
            else cout << "#bt " << nombre << endl;

            bool exists = c.existe_torneo(nombre);

            if (not exists) cout << "error: el torneo no existe" << endl;
            else {
                pair<string,Torneo> t = c.consultar_torneo(nombre);
        
                cjt_j.actualizar_jugadores_torneo_borrado(t.second);
                c.borrar_torneo(nombre);
                cout << c.num_torneos() << endl;
            }
        }
        else if (comando == "iniciar_torneo" or comando == "it") {
            string nombre;
            cin >> nombre;

            if (comando == "iniciar_torneo") cout << "#iniciar_torneo " << nombre << endl;
            else cout << "#it " << nombre << endl;

            pair<string,Torneo> t = c.consultar_torneo(nombre);
            Jugador j;
            int n, pos;
            cin >> n;

            for(int i = 0; i < n; ++i) {
                cin >> pos;
                pair<string,Jugador> j = cjt_j.consultar_jugadorR(pos);
                t.second.anadir_jugador(j.first,j.second);
            }

            t.second.iniciar_torneo();
            c.modificar_torneo(t.first, t.second);

        }
        else if (comando == "finalizar_torneo" or comando == "ft") {
            string nombre;
            cin >> nombre;

            if (comando == "finalizar_torneo") cout << "#finalizar_torneo " << nombre << endl;
            else cout << "#ft " << nombre << endl;

            pair<string,Torneo> t = c.consultar_torneo(nombre);

            for (int i = 0; i < t.second.num_jugadores(); ++i) {
                pair<string,Jugador> j = t.second.consultar_jugador(i);
                if (cjt_j.existe_jugador(j.first)) {
                    Jugador nw = cjt_j.consultar_jugador(j.first);
                    t.second.modificar_jugador(i, nw);
                }
                else {
                    t.second.eliminar_jugador(j.first);
                }
            }

            t.second.finalizar_torneo();
            
            cjt_j.actualizar_jugadores_torneo_finalizado(t.second);

            t.second.actualizar_ultimo_torneo();
            t.second.vaciar_torneo();

            c.modificar_torneo(t.first, t.second);
        }
        else if (comando == "listar_ranking" or comando == "lr") {
            if (comando == "listar_ranking") cout << "#listar_ranking" << endl;
            else cout << "#lr" << endl;

            cjt_j.escribirR();
        }
        else if (comando == "listar_jugadores" or comando == "lj") {
            if (comando == "listar_jugadores") cout << "#listar_jugadores" << endl;
            else cout << "#lj" << endl;
            cjt_j.escribir();
        }
        else if (comando == "consultar_jugador" or comando == "cj") {
            string nombre;
            cin >> nombre;

            if (comando == "consultar_jugador") cout << "#consultar_jugador " << nombre << endl;
            else cout << "#cj " << nombre << endl;

            bool exists = cjt_j.existe_jugador(nombre);
            if (not exists) cout << "error: el jugador no existe" << endl;
            else {
                Jugador j = cjt_j.consultar_jugador(nombre);
                cout << nombre;
                j.escribir();
            }
        }
        else if (comando == "listar_torneos" or comando == "lt") {
            if (comando == "listar_torneos") cout << "#listar_torneos" << endl;
            else cout << "#lt" << endl;
            c.escribir_torneos();
        } 
        else if (comando == "listar_categorias" or comando == "lc") {
            if (comando == "listar_categorias") cout << "#listar_categorias" << endl;
            else cout << "#lc" << endl;
            c.escribir_categorias();
        }
        cin >> comando;
    }
}