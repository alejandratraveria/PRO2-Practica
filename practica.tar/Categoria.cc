#include "Categoria.hh"

Categoria::Categoria() {
    this->nombre = "";
    this->puntos_nivel = vector<int>();
}

Categoria::Categoria (string nombre) {
    this->nombre = nombre;
    this->puntos_nivel = vector<int>();
}

Categoria::~Categoria(){}

string Categoria::consultar_nombre() const {
    return nombre;
}

int Categoria::consultar_puntos_lvl(int lvl) const {
    return puntos_nivel[lvl-1];
}

void Categoria::leer_puntos_por_nivel(int k) {
    puntos_nivel = vector<int>(k);
    for (int i = 0; i < k; ++i) {
        cin >> puntos_nivel[i];
    }
}

void Categoria::escribir() const {
    cout << nombre;
    for (int i = 0; i < puntos_nivel.size(); ++i) {
        cout << " " << puntos_nivel[i];
    }
    cout << endl;
}