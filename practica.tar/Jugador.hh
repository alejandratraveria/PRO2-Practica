/** @file Jugador.hh
    @brief Especificación de la clase Jugador 
*/
#ifndef _JUGADOR
#define _JUGADOR

#ifndef NO_DIAGRAM
#include <iostream>
#include <set>
#endif

using namespace std;

/** @class Jugador
    @brief Representa un Jugador 
*/

class Jugador {
    public:
        //Constructoras:

        /** @brief Creadora sin argumentos
             \pre <em>Cierto</em>
             \post El resultado es un jugador vacio
        */       
        Jugador();

        /** @brief Creadora con atributo 
             \pre <em>Cierto</em>
             \post El resultado es un jugador con ranking <em>ranking</em> y todas sus estadísticas a 0
        */ 
        Jugador(int ranking);

        //Destructoras:

        /** @brief Destructora
             \pre <em>Cierto</em>
             \post Se destruye el objeto jugador
        */ 
        ~Jugador();

        //Consultoras:

        /** @brief Consultora de puntos de un jugador
             \pre <em>Cierto</em>
             \post El resultado son los puntos del jugador 
        */ 
        int consultar_puntos() const;

        /** @brief Consultora del ranking de in jugador
             \pre <em>Cierto</em>
             \post El resultado es el ranking del jugador 
        */ 
        int consultar_ranking() const;

        /** @brief Consultora de los partidos ganados de un jugador
             \pre <em>Cierto</em>
             \post El resultado es el numero de partidos ganados del jugador 
        */ 
        int consultar_partidos_ganados() const;

        /** @brief Consultora de los partidos perdidos de un jugador
             \pre <em>Cierto</em>
             \post El resultado es el numero de partidos perdidos del jugador 
        */ 
        int consultar_partidos_perdidos() const;

        /** @brief Consultora del numero de sets ganados de un jugador
             \pre <em>Cierto</em>
             \post El resultado es el numero de sets ganados del jugador 
        */ 
        int consultar_sets_ganados() const;

        /** @brief Consultora del numero de sets perdidos de un jugador
             \pre <em>Cierto</em>
             \post El resultado es el numero de sets perdidos del jugador 
        */ 
        int consultar_sets_perdidos() const;

        /** @brief Consultora de juegos ganados de un jugador
             \pre <em>Cierto</em>
             \post El resultado es el numero de juegos ganados del jugador 
        */ 
        int consultar_juegos_ganados() const;

        /** @brief Consultora de juegos perdidos de un jugador
             \pre <em>Cierto</em>
             \post El resultado es el numero de juegos perdidos del jugador
        */ 
        int consultar_juegos_perdidos() const;

        /** @brief Consultora de los puntos del último torneo
             \pre <em>Cierto</em>
             \post El resultado son los puntos del último torneo
        */ 
        int consultar_puntos_ultimo_torneo() const;

        /** @brief Consultora que consulta los torneos disputados 
             \pre <em>Cierto</em>
             \post El resultado es el número de torneos disputados
        */ 
        int consultar_torneos() const;

        //Modificadoras:

        /** @brief Modificadora que modifica el ranking del jugador
             \pre <em>Cierto</em>
             \post El resultado es el jugador con su nueva posición en el ranking <em>ranking</em>
        */ 
        void modificar_ranking(int ranking);

        /** @brief Modificadora que modifica el numero de torneos disputados
             \pre <em>Cierto</em>
             \post El resultado es el numero de torneos disputados más <em>n</em> 
        */ 
        void incrementar_torneos_disputados(int n);

        /** @brief Modificadora que incrementa los puntos del jugador 
             \pre <em>Cierto</em>
             \post El resultado es el jugador con sus puntos más los nuevos puntos <em>puntos</em>
        */ 
        void incrementar_puntos(int puntos);

        /** @brief Modificadora que incrementa el numero de partidos ganados del jugador
             \pre <em>Cierto</em>
             \post El resultado es el jugador con su numero de partidos ganados más los nuevos partidos ganados <em>partidos_ganados</em>
        */ 
        void incrementar_partidos_ganados(int partidos_ganados);

        /** @brief Modificadora que incrementa el numero de partidos perdidos del jugador
             \pre <em>Cierto</em>
             \post El resultado es el jugador con su numero de partidos perdidos más los nuevos partidos perdidos <em>partidos_perdidos</em>
        */ 
        void incrementar_partidos_perdidos(int partidos_perdidos);

        /** @brief Modificadora que incrementa el numero de sets ganados del jugador
             \pre <em>Cierto</em>
             \post El resultado es el jugador con su numero de sets ganados más los nuevos sets ganados <em>sets_ganados</em>
        */ 
        void incrementar_sets_ganados(int sets_ganados);

        /** @brief Modificadora que incrementa el numero de sets perdidos del jugador
             \pre <em>Cierto</em>
             \post El resultado es el jugador con su numero de sets perdidos más los nuevos sets perdidos <em>sets_perdidos</em>
        */ 
        void incrementar_sets_perdidos(int sets_perdidos);

        /** @brief Modificadora que incrementa el numero de juegos ganados del jugador
             \pre <em>Cierto</em>
             \post El resultado es el jugador con su numero de juegos ganados más los nuevos juegos ganados <em>juegos_ganados</em>
        */ 
        void incrementar_juegos_ganados(int juegos_ganados);

        /** @brief Modificadora que incrementa el numero de juegos perdidos del jugador
             \pre <em>Cierto</em>
             \post El resultado es el jugador con su numero de juegos perdidos mas los nuevos juegos perdidos <em>juegos_perdidos</em>
        */ 
        void incrementar_juegos_perdidos(int juegos_perdidos);

        /** @brief Modificadora que modifica los puntos del ultimo torneo
             \pre <em>Cierto</em>
             \post El resultado son los puntos <em>puntos</em> del ultimo torneo actualizados
        */ 
        void modificar_puntos_ultimo_torneo(int puntos);

        //Escribir:

        /** @brief Operacíon de escritura del jugador
             \pre <em>Cierto</em>
             \post Se escribe por el canal estandard al jugador
        */ 
        void escribir() const;

    private:
        /** @brief Ranking del jugador
        */ 
        int ranking;
        /** @brief Numero de torneos disputados
        */ 
        int torneos_d;
        /** @brief Puntos totales
        */ 
        int puntos;
        /** @brief Puntos del ultimo torneo jugado
        */ 
        int puntos_ultimo_torneo;
        /** @brief Numero de partidos ganados
        */ 
        int partidos_ganados;
        /** @brief Numero de partidos perdidos
        */ 
        int partidos_perdidos;
        /** @brief Numero de sets ganados
        */ 
        int sets_ganados;
        /** @brief Numero de sets perdidos
        */ 
        int sets_perdidos;
        /** @brief Numero de juegos ganados
        */ 
        int juegos_ganados;
        /** @brief Numero de juegos perdidos
        */ 
        int juegos_perdidos;
};

#endif
