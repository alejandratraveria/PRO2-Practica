#include "Torneo.hh"

    Torneo::Torneo() {
        this->categoria = Categoria();
        edicion = 0;
        numero_inscritos = 0;
        jugadores = vector<pair<string,Jugador>>();
        cuadro_emparejamientos = BinTree<int>();
        resultados = BinTree<string>();
        last_players_points = vector<pair<string,pair<Jugador,int>>>();
    }

    Torneo::Torneo(const Categoria& c) {
        this->categoria = c;
        edicion = 1;
        numero_inscritos = 0;
        jugadores = vector<pair<string,Jugador>>();
        cuadro_emparejamientos = BinTree<int>();
        resultados = BinTree<string>();
        last_players_points = vector<pair<string,pair<Jugador,int>>>();
    }

    Torneo::~Torneo() {}

    int Torneo::consultar_edicion() const {
        return edicion;
    }

    pair<string,Jugador> Torneo::consultar_jugador(int rank_rel) const {
        return jugadores[rank_rel];
    }

    pair<string,pair<Jugador,int>> Torneo::consultar_jugador_ultima_edicion(int pos) const {
        return last_players_points[pos];
    }

    int Torneo::jugadores_ultima_edicion() const {
        return last_players_points.size();
    }

    int Torneo::num_jugadores() const {
        return jugadores.size();
    }

    Categoria Torneo::consultar_categoria() const {
        return categoria;
    }

    void Torneo::vaciar_torneo() {
        numero_inscritos = 0;
        jugadores = vector<pair<string,Jugador>>();
        cuadro_emparejamientos = BinTree<int>();
        resultados = BinTree<string>();
    }

    void Torneo::actualizar_ultimo_torneo() {
        last_players_points = last_players_points = vector<pair<string,pair<Jugador,int>>>(jugadores.size());
        for (int j = 0; j < jugadores.size(); ++j) {
            last_players_points[j] = {jugadores[j].first,{jugadores[j].second, jugadores[j].second.consultar_puntos_ultimo_torneo()}};
        }
    }

    void Torneo::iniciar_torneo() {
        int N = jugadores.size();
        int H = ceil(log2(N))+1;
        int M = pow(2,H-1);

        get_cuadro(N,M,H,2,1,1,cuadro_emparejamientos);
        escribir_cuadro(cuadro_emparejamientos);
        cout << endl;
    }

    void Torneo::finalizar_torneo() {
        int N = jugadores.size();
        int H = ceil(log2(N))+1;
        int M = pow(2,H-1);
        int n_nodes = pow(2,H)-(1-(2*(N-M)));
        int i = 0;

        // read
        get_results(resultados, n_nodes, i);

        // play
        BinTree<int> res;
        play_tournament(cuadro_emparejamientos,resultados, 1, res, M, N, H);
        jugadores[res.value()-1].second.modificar_puntos_ultimo_torneo(categoria.consultar_puntos_lvl(1));

        // write
        escribir_resultados(res, resultados);
        cout << endl;
        for (int j = 0; j < jugadores.size(); ++j) {
            jugadores[j].second.incrementar_torneos_disputados(1);
            if (jugadores[j].second.consultar_puntos_ultimo_torneo() > 0) {
                cout << j + 1 << "." << jugadores[j].first << " " << jugadores[j].second.consultar_puntos_ultimo_torneo() << endl;
            }
        }
        edicion += 1;
    }

        void Torneo::anadir_jugador(string nombre, const Jugador& j) {
        bool found = false;
        for (int i = 0; i < last_players_points.size() and not found; ++i) {
            if (last_players_points[i].first == nombre) {
                found = true;
                if (j.consultar_torneos() < last_players_points[i].second.first.consultar_torneos()) {
                    last_players_points[i].second.second = 0;
                }
            }
        }
        jugadores.push_back({nombre, j});
    }

    void Torneo::modificar_jugador(int pos, const Jugador& j) {
        jugadores[pos].second = j;
    }

    void Torneo::eliminar_jugador(string nombre) {
        int i = 0;
        bool found = false;
        while (i < jugadores.size() and not found) {
            if (jugadores[i].first == nombre) found = true;
            else ++i;
        }

        jugadores.erase(jugadores.begin() + i - 1);
    }

    void Torneo::escribir() const {
        cout << ' ' << categoria.consultar_nombre() << endl;
    }

    void Torneo::get_cuadro(const int N, const int M, const int H, int Z, int a_prev, int lvl, BinTree<int>& b) {

        BinTree<int> l;
        BinTree<int> r;

        if (lvl+1 == H) {
           if (a_prev <= M - N) b = BinTree<int>(a_prev);
           else {
              get_cuadro(N, M, H, Z*2, a_prev, lvl + 1, l);
              get_cuadro(N, M, H, Z*2, Z + 1 - a_prev, lvl + 1, r);

              b = BinTree<int>(a_prev, l, r);
           }
        }
        else if (lvl == H) b = BinTree<int>(a_prev);
        else {
            get_cuadro(N, M, H, Z*2, a_prev, lvl + 1, l);
            get_cuadro(N, M, H, Z*2, Z + 1 - a_prev, lvl + 1, r);

            b = BinTree<int>(a_prev, l, r);
        }
      
    }

    void Torneo::get_results(BinTree<string> &t, int n_nodes, int &i) {
        string aux;
        if (i < n_nodes) {
            cin >> aux;
            ++i;

            BinTree<string> l;
            BinTree<string> r;

            if (aux == "0") {
                t = BinTree<string>(aux);
            }
            else {
                get_results(l, n_nodes, i);
                get_results(r, n_nodes, i);

                t = BinTree<string>(aux, l, r);
            }
        }
    }

    void Torneo::play_tournament(BinTree<int> v, BinTree<string> t, int lvl, BinTree<int>& res, int M, int N, int H) {

        if (lvl == H or (lvl+1 == H and v.value() <= M-N)) {
            res = BinTree<int>(v.value());
        }

        else {
            BinTree<int> l;
            BinTree<int> r;

            play_tournament(v.left(), t.left(), lvl+1, l, M, N, H);
            play_tournament(v.right(), t.right(), lvl+1, r, M, N, H);


            string aux = t.value();
            res = BinTree<int>(v.value(), l, r);

            // a1-b1,a2-b2,a3-b3
            if (aux.length() == 11) {
                jugadores[res.left().value()-1].second.incrementar_sets_ganados(1);
                jugadores[res.right().value()-1].second.incrementar_sets_perdidos(1);

                jugadores[res.right().value()-1].second.incrementar_sets_ganados(1);
                jugadores[res.left().value()-1].second.incrementar_sets_perdidos(1);

                jugadores[res.left().value()-1].second.incrementar_juegos_ganados((aux[0] - '0') + (aux[4] - '0') + (aux[8] - '0'));
                jugadores[res.left().value()-1].second.incrementar_juegos_perdidos((aux[2] - '0') + (aux[6] - '0') + (aux[10] - '0'));

                jugadores[res.right().value()-1].second.incrementar_juegos_ganados((aux[2] - '0') + (aux[6] - '0') + (aux[10] - '0'));
                jugadores[res.right().value()-1].second.incrementar_juegos_perdidos((aux[0] - '0') + (aux[4] - '0') + (aux[8] - '0'));

                if ((aux[8] - '0') > (aux[10] - '0')) {
                    jugadores[res.right().value()-1].second.modificar_puntos_ultimo_torneo(categoria.consultar_puntos_lvl(lvl+1));

                    jugadores[res.left().value()-1].second.incrementar_partidos_ganados(1);
                    jugadores[res.right().value()-1].second.incrementar_partidos_perdidos(1);

                    jugadores[res.left().value()-1].second.incrementar_sets_ganados(1);
                    jugadores[res.right().value()-1].second.incrementar_sets_perdidos(1);

                    res = BinTree<int>(res.left().value(), l, r);
                }

                else {
                    jugadores[res.left().value()-1].second.modificar_puntos_ultimo_torneo(categoria.consultar_puntos_lvl(lvl+1));

                    jugadores[res.right().value()-1].second.incrementar_partidos_ganados(1);
                    jugadores[res.left().value()-1].second.incrementar_partidos_perdidos(1);

                    jugadores[res.right().value()-1].second.incrementar_sets_ganados(1);
                    jugadores[res.left().value()-1].second.incrementar_sets_perdidos(1);

                    res = BinTree<int>(res.right().value(), l, r);
                }

            }

            // a1-b1,a2-b2
            else if (aux.length() == 7) {

                jugadores[res.left().value()-1].second.incrementar_juegos_ganados((aux[0] - '0') + (aux[4] - '0'));
                jugadores[res.left().value()-1].second.incrementar_juegos_perdidos((aux[2] - '0') + (aux[6] - '0'));

                jugadores[res.right().value()-1].second.incrementar_juegos_ganados((aux[2] - '0') + (aux[6] - '0'));
                jugadores[res.right().value()-1].second.incrementar_juegos_perdidos((aux[0] - '0') + (aux[4] - '0'));

                // a wins
                if ((aux[0] - '0') > (aux[2] - '0')) {
                    jugadores[res.right().value()-1].second.modificar_puntos_ultimo_torneo(categoria.consultar_puntos_lvl(lvl+1));

                    jugadores[res.left().value()-1].second.incrementar_partidos_ganados(1);
                    jugadores[res.right().value()-1].second.incrementar_partidos_perdidos(1);

                    jugadores[res.left().value()-1].second.incrementar_sets_ganados(2);
                    jugadores[res.right().value()-1].second.incrementar_sets_perdidos(2);

                    res = BinTree<int>(res.left().value(), l, r);
                }

                // b wins
                else {
                    jugadores[res.left().value()-1].second.modificar_puntos_ultimo_torneo(categoria.consultar_puntos_lvl(lvl+1));

                    jugadores[res.right().value()-1].second.incrementar_partidos_ganados(1);
                    jugadores[res.left().value()-1].second.incrementar_partidos_perdidos(1);

                    jugadores[res.right().value()-1].second.incrementar_sets_ganados(2);
                    jugadores[res.left().value()-1].second.incrementar_sets_perdidos(2);

                    res = BinTree<int>(res.right().value(), l, r);
                }
            }

            // 1-0 o 0-1
            else {
                // a wins
                if (aux[0] == '1') {
                    jugadores[res.left().value()-1].second.incrementar_partidos_ganados(1);
                    jugadores[res.right().value()-1].second.incrementar_partidos_perdidos(1);

                    jugadores[res.right().value()-1].second.modificar_puntos_ultimo_torneo(categoria.consultar_puntos_lvl(lvl+1));

                    res = BinTree<int>(res.left().value(), l, r);
                }

                // b wins
                else {
                    jugadores[res.right().value()-1].second.incrementar_partidos_ganados(1);
                    jugadores[res.left().value()-1].second.incrementar_partidos_perdidos(1);

                    jugadores[res.left().value()-1].second.modificar_puntos_ultimo_torneo(categoria.consultar_puntos_lvl(lvl+1));

                    res = BinTree<int>(res.right().value(), l, r);
                }
            }
        }
    }

    void Torneo::escribir_cuadro(const BinTree<int> &v) const {
        if (not v.empty()) {
            if (v.left().left().empty() and v.right().right().empty()) {
                cout << "(" << v.left().value() << "." << jugadores[v.left().value()-1].first << " "
                                        << v.right().value() << "." << jugadores[v.right().value()-1].first << ")";
            }
            else if (v.left().left().empty() and not v.right().right().empty()) {
                cout << "(" << v.left().value() << "." << jugadores[v.left().value()-1].first << " ";

                if (not v.right().empty()) {
                    escribir_cuadro(v.right());
                    cout << ")";
                }
            }

            else {
                cout << "(";
                escribir_cuadro(v.left());
                cout << " ";
                escribir_cuadro(v.right());
                cout << ")";
            }
        }
    }

    void Torneo::escribir_resultados(const BinTree<int>& v, const BinTree<string>& t) const {
        if (not v.empty() and not v.left().left().empty() and not v.right().right().empty()) {
                cout << "(" << v.left().value() << "." << jugadores[v.left().value()-1].first << " vs "
                     << v.right().value() << "." << jugadores[v.right().value()-1].first << " " << t.value();
                escribir_resultados(v.left(),t.left());
                escribir_resultados(v.right(),t.right());
                cout << ")";
        }

        else  {
            if (v.left().left().empty() and not v.right().right().empty()) {
                cout << "(" << v.left().value() << "." << jugadores[v.left().value()-1].first << " vs "
                     << v.right().value() << "." << jugadores[v.right().value()-1].first << " " << t.value();
                escribir_resultados(v.right(),t.right());
                cout << ")";
            }
            else {
                cout << "(" << v.left().value() << "." << jugadores[v.left().value()-1].first << " vs "
                     << v.right().value() << "." << jugadores[v.right().value()-1].first << " " << t.value() << ")";
            }
        }


    }
